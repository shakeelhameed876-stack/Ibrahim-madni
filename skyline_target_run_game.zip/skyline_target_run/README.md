# SKYLINE TARGET RUN

A single-file browser 3D first-person target challenge built with Three.js.

## Run locally
Open `index.html` in a modern browser. Internet access is required because Three.js is loaded from jsDelivr.

For local hosting, from this folder run:
python -m http.server 8000
Then open http://localhost:8000

## Controls
WASD = move
Mouse = look
Click = tag target under reticle
Shift = sprint
P / Esc = pause and release pointer

## Publish free
### Netlify
1. Sign in at https://app.netlify.com/
2. Choose Add new project / Deploy manually (wording can vary).
3. Drag the `skyline_target_run` folder into the deploy area.
4. Netlify gives you a free `netlify.app` URL.

### GitHub Pages
1. Create a public GitHub repository.
2. Upload `index.html`.
3. Settings -> Pages.
4. Deploy from the `main` branch, root folder.
5. Your site gets a `github.io` URL.

### Cloudflare Pages
1. Open Workers & Pages.
2. Create a Pages/Workers project using Direct Upload.
3. Upload the folder or its ZIP.
4. Deploy.
5. Cloudflare provides a `pages.dev` URL.

No paid hosting is required for the basic static version.
